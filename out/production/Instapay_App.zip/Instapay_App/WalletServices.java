public class WalletServices extends Services {

    @Override
    public void transfer() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'transfer'");
    }
    
}

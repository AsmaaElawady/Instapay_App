public class ToInstaPayTransaction extends Transaction{

    @Override
    public void recieverInfo() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'recieverInfo'");
    }

    @Override
    public void authenticate() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'authenticate'");
    }

    @Override
    public void transfer() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'transfer'");
    }
    
}

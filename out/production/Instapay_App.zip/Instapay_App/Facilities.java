import java.util.*;


 public interface Facilities {

  public Bill createBill(Account account);
    

 } 


public interface Authentication {
    public boolean authenticateProvidedInfo(String ID);
}

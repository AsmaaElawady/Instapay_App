public abstract class Services {
    public abstract void transfer();
    public void payBills() {} ////////////////////////
}

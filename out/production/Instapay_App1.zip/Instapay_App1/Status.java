public enum Status {
    Active , InActive , Frozen, OverDrawn, Closed, Suspended;
    public static Status DEFAULT = Active;

    }
